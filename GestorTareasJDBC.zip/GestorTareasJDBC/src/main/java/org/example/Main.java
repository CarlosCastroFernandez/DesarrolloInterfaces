package org.example;

import dominio.DataBase;
import ui.Ventana;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        Ventana v=new  Ventana();

    }
}