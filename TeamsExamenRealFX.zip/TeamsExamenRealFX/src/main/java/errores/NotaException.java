package errores;

public class NotaException extends Exception{
    public NotaException(String message) {
        super(message);
    }
}
