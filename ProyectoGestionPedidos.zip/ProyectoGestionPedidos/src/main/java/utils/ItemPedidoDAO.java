package utils;

import clases.Itempedido;
import clases.Pedido;

import java.util.ArrayList;

public interface ItemPedidoDAO {

    public ArrayList<Itempedido> loadItem (Pedido codigo);
}
