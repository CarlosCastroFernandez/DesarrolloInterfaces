package errores;

public class MarcadorIncompatible extends Exception{
    public MarcadorIncompatible(String mensaje){
        super(mensaje);
    }
}
