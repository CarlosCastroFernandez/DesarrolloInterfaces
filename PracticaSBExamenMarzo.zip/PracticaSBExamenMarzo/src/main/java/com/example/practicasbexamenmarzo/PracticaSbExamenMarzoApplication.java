package com.example.practicasbexamenmarzo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaSbExamenMarzoApplication {

    public static void main(String[] args) {
        SpringApplication.run(PracticaSbExamenMarzoApplication.class, args);
    }

}
