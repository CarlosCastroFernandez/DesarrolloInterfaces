package com.example.practicasbexamenmarzo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaSbExamenMarzoApplicationTests {

    @Test
    void contextLoads() {
    }

}
