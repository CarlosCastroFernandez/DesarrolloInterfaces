package dao;

import clase.Curso;
import clase.PersonalIIP;

import java.util.List;

public interface DAOInstructorCurso {

}
