package implement;

import Util.HibernateUtil;
import clase.Curso;
import clase.PersonalIIP;
import dao.DAOInstructorCurso;
import org.hibernate.Session;
import org.hibernate.query.Query;


import java.util.List;

public class InstructorCursoDAOImplement implements DAOInstructorCurso {

}
