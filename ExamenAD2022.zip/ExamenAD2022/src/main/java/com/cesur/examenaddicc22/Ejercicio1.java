package com.cesur.examenaddicc22;

import java.io.BufferedReader;
import java.io.FileReader;

class Ejercicio1 {

    /**
     * Enunciado:
     * 
     * Completar el método estadísticasDeArchivo de manera que lea el archivo
     * de texto que se le pasa como parámetro, lo analice y muestre por consola 
     * el número de caracteres, palabras y líneas total.
     * 
     * Modificar solo el código del método.
     * 
     */
    
    static void solucion() {

        estadísticasDeArchivo("pom.xml");
    }

    private static void estadísticasDeArchivo(String archivo) {
        
        /* añadir código */
        String copia="";
        String linea;
        String copiaLetras="";
        Integer contadorLinea=0;
        Integer contadorLetras=0;
        try(BufferedReader lectura=new BufferedReader(new FileReader("./pom.xml"))){
            while((linea= lectura.readLine())!=null){
                contadorLinea++;
            }
            System.out.println(contadorLinea +" Lineas");
            for(int i=0;i<copia.length();i++) {
                contadorLetras++;

            }
            System.out.println(contadorLetras + " caracteres");

            String[]espacios=copia.split(" ");
            String copiaPalabras="";
            Integer contadorPalabras=0;
            for(int i=0;i<espacios.length;i++){
                System.out.println(espacios[i]);
               if(espacios[i].equals("")&&i==8){
                   espacios[i]="1"+espacios[i];
               }
                if(!espacios[i].equals("")){
                    copiaPalabras+=espacios[i]+" ";
                    contadorPalabras++;
                }
            }
            copiaPalabras.strip();
            System.out.println(contadorPalabras+" palabras");



        }catch (Exception e){
            e.printStackTrace();
        }
        
       // System.out.println("Ejercicio no resuelto");
    }
    
}
