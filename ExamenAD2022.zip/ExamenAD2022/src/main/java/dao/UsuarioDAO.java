package dao;

import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Usuario;

public class UsuarioDAO {
    
    private Connection connection;
    
    /* Completar consultas */
    static final String INSERT_QUERY ="insert into usuario (nombre,apellidos,dni) VALUES (?,?,?)";
    static final String LIST_QUERY="select * from usuario";
    static final String GET_BY_DNI="select * from usuario where dni=?";
    
    
    public void connect(){
        try {
            InputStream is=UsuarioDAO.class.getClassLoader().getResourceAsStream("bbdJDBC.cfg");
            Properties properties=new Properties();
            properties.load(is);
            String url="jdbc:mysql://";
            connection= DriverManager.getConnection(url+properties.getProperty("host")+":"+properties.getProperty("port")+"/"+properties.getProperty("name"), properties.getProperty("user"), properties.getProperty("password"));
            System.out.println("Base de datos  conectada");
        }catch(Exception ex){
            System.out.println("Error al conectar a la base de datos");
            System.out.println("ex");
        }     
    }
    
    public void close(){
        try {
            connection.close();
        } catch (Exception ex) {
            System.out.println("Error al cerrar la base de datos");     
        }
    }
    
    public void save(Usuario user){
        
        /**
         * Completar código para guardar un usuario 
         * Este método no debe generar el id del usuario, ya que la base
         * de datos es la que lo genera.
         * Una vez obtenido el id del usuario tras la consulta sql,
         * hay que modificarlo en el objeto que se pasa como parámetro 
         * de forma que pase a tener el id correcto.
         */
        try {
            PreparedStatement pst=connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1,user.getNombre());
            pst.setString(2,user.getApellidos());
            pst.setString(3,user.getDni());
            Integer filas=pst.executeUpdate();
            if(filas==1){
                ResultSet rs=pst.getGeneratedKeys();
                rs.next();
                user.setId((long) rs.getInt(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

    public ArrayList<Usuario> list(){

        var salida = new ArrayList<Usuario>(0);

        
        /* Completar código para devolver un arraylist con todos los usuarios */
        try {
            Statement st=connection.createStatement();
            ResultSet rs=st.executeQuery(LIST_QUERY);
            while(rs.next()){
                Usuario usuario=new Usuario();
            usuario.setId((long) rs.getInt("id"));
            usuario.setDni(rs.getString("dni"));
            usuario.setApellidos(rs.getString("apellidos"));
            usuario.setNombre(rs.getString("nombre"));
            salida.add(usuario);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

      //  System.out.println("Método list no completado");
        
        return salida;
    }    
    
    public Usuario getByDNI(String dni){
        
        Usuario salida = new Usuario();
        try {
            PreparedStatement pst=connection.prepareStatement(GET_BY_DNI);
            pst.setString(1,dni);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                salida.setId((long) rs.getInt("id"));
                salida.setDni(rs.getString("dni"));
                salida.setNombre(rs.getString("nombre"));
                salida.setApellidos(rs.getString("apellidos"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        /**
         * Completar código para devolver el usuario que tenga ese dni.
         * Si no existe, se debe devolver null
         */

        return salida;
    }    
}
