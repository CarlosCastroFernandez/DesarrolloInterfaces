package dao;

import java.util.ArrayList;
import java.util.HashSet;

import models.Ejemplar;
import models.Libro;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

/**
 *
 * @author FranciscoRomeroGuill
 */
public class BibliotecaDAO {
    
    private static SessionFactory sessionFactory;
    
    static{
        try{

            Configuration c=new Configuration();
            c.configure("hibernate.cfg.xml");
            sessionFactory=c.buildSessionFactory();
            System.out.println("Conexión realizada");
        }catch(Exception ex){
            System.out.println("Error iniciando Hibernate");
            System.out.println(ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
    public static SessionFactory sesion(){
        return sessionFactory;
    }
    
    public void saveLibro( Libro e ){
        
        /* Guarda un libro con todos sus ejemplares en la base de datos */
        try(Session s=sessionFactory.openSession()){
            Transaction t=s.beginTransaction();
            s.persist(e);
            for(int i=0;i<e.getEjemplares().size();i++){
                s.persist(e.getEjemplares().get(i));
            }
            t.commit();
        }
        
        System.out.println("Método saveLibro no implementado");
        
    }
  
    public HashSet<Libro> findByEstado(String estado){
        
        HashSet<Libro> salida = new HashSet<Libro>();
        ArrayList<Libro>todos=new ArrayList<>();

        /* 
         Devuelve el conjunto de libros que tenga el estado indicado      
        */
        try(Session s=sessionFactory.openSession()){
            Query<Libro>q=s.createQuery("From Libro");
           todos= (ArrayList<Libro>) q.getResultList();
           for(int i=0;i<todos.size();i++){
               if(todos.get(i).getEjemplares().get(i).getEstado().contains(estado)){
                   salida.add(todos.get(i));
               }
           }
           }catch (Exception e){
            e.printStackTrace();

        }
        //System.out.println("Método findByEstado no implementado");
        
        return salida;
        
    }
    
    public void printInfo(){
        
        /* 
          Muestra por consola todos los libros de la biblioteca y el número
          de ejemplares disponibles de cada uno.
          
          Debe imprimirlo de esta manera:
        
          Biblioteca
          ----------
          Como aprender java en 24h. (3)
          Como ser buena persona (1)
          Aprobando exámenes fácilmente (5)
          ...
        
        */
        ArrayList<Libro>libros=new ArrayList<>();
        try(Session s=sessionFactory.openSession()){
            Query q=s.createQuery("From Libro");
            libros= (ArrayList<Libro>) q.getResultList();
        }
        libros.forEach(li->{
            System.out.println(li);
        });
        System.out.println("Método printInfo no implementado");
        
    }
    
}
